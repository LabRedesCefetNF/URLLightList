package urllightlist.excecao;

public class ManipulacaoDeArquivoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ManipulacaoDeArquivoException(String mensagem){
		super(mensagem);
	}
	
}
