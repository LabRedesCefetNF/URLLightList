package urllightlist.colecao;

import urllightlist.entidade.Reclassificacao;

public interface ColecaoReclassificacao extends Colecao<Reclassificacao> {}
