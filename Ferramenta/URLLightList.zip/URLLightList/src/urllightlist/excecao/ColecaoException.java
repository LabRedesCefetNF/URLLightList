package urllightlist.excecao;

public class ColecaoException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ColecaoException(String mensagem){
		super(mensagem);
	}
	

}
