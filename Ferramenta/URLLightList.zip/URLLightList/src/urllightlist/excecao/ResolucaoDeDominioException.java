package urllightlist.excecao;

public class ResolucaoDeDominioException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ResolucaoDeDominioException(String mensagem){
		super(mensagem);
	}

}
