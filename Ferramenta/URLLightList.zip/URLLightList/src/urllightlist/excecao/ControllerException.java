package urllightlist.excecao;

public class ControllerException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ControllerException(String mensagem){
		super(mensagem);
	}
	
}
